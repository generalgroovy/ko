# EP-133 File Protocol Knowledge

Verified against the connected EP-133 on June 11, 2026. All discovery in this
document used read-only operations. Device upload, delete, move, restore, and
metadata writes remain blocked.

## Transport

- MIDI transport: direct Windows WinMM input/output named `EP-133`.
- Manufacturer SysEx id: `00 20 76`.
- TE frame marker: `40`.
- File command: `05`.
- Payload bytes are packed into MIDI-safe 7-bit data.
- Requests and responses use a 14-bit request id.
- Responses must be matched by command and request id. The device can emit
  unrelated diagnostic SysEx while a request is pending.

## File Session

File init request payload:

```text
01 flags max_response_length:u32be
```

The connected unit returned a 512-byte file-protocol chunk size. The practical
GET data payload observed through the packed SysEx transport is 324 raw bytes
per full page.

## Directory Listing

List request payload:

```text
04 page:u16be parent_node:u16be
```

Each response starts with the returned page number followed by zero or more
records:

```text
node:u16be flags:u8 size:u32be utf8_name:nul
```

Confirmed roots:

- node 1000: `/sounds`
- node 2000: `/projects`

The June 11 snapshot contains 328 PCM sounds and nine project directories.

## File Download

GET init request:

```text
03 00 node:u16be offset:u32be
```

GET init response:

```text
node:u16be flags:u8 size:u32be utf8_name:nul padding...
```

GET data request:

```text
03 01 page:u16be
```

GET data response:

```text
page:u16be raw_file_bytes...
```

The client must continue requesting pages until exactly the declared byte
count has been received. Empty early pages, unexpected page numbers, overflow,
or a size mismatch are failures.

Verified sound download:

- node: 207
- device path: `/sounds/207.pcm`
- device metadata name: `closed hat foot`
- size: 3,988 bytes
- pages: 13
- page sizes: twelve 324-byte pages plus one 100-byte page
- SHA-256:
  `a6776d9fc2fded058e33c98874b7ce51eede2f6eea71b6edd9968f506899befd`
- CRC32: `2251392378` (`0x8631857a`)
- metadata CRC matched the downloaded bytes
- format: signed 16-bit PCM, mono, 46,875 Hz
- frames: 1,994

## Metadata

Metadata GET request:

```text
07 02 node:u16be page:u16be [utf8_key:nul]
```

Each response begins with the returned page and contains part of a UTF-8 JSON
object. A NUL terminator marks the last page.

Observed sound metadata fields include:

- `name`
- `channels`
- `samplerate`
- `format`
- `crc`
- `sound.playmode`
- `sound.rootnote`
- `sound.pitch`
- `sound.pan`
- `sound.amplitude`
- `sound.bars`
- `sound.bpm`
- `sound.loopstart`
- `sound.loopend`
- `envelope.attack`
- `envelope.release`
- `time.mode`

The metadata `crc` value is the standard CRC32 of the raw PCM bytes.

## Project Archives

GET init on project node 3000 returned:

- name: `01`
- flags: `14`
- archive size: 55,808 bytes

This proves project directories expose a downloadable archive representation.
The complete archive transfer was not verified in this session because the
manual reverse-engineering probe intentionally stopped after GET init.

## Transaction Safety

A GET init creates a stateful device read transaction. A manual probe that
starts GET and does not consume every data page can leave the device file
service returning diagnostic SysEx such as:

```text
err lfs 6327 2_0_5
```

Recovery requires reconnecting or power-cycling the EP-133. Restarting the
Windows PnP device requires administrator access and is not used by the app.

The integrated downloader therefore:

- never exposes a standalone live GET-init command
- serializes all SysEx transactions
- reads every declared byte before metadata or local file work
- ignores unrelated diagnostic SysEx while matching responses
- suppresses progress callback failures until the device read completes
- blocks normal GUI disconnect, reconnect, and close while a download is active
- writes immutable content-addressed local bundles
- verifies SHA-256 for every download and CRC32 when metadata supplies it

## Local Bundle

Downloaded content is stored under:

```text
daw_projects/device_library/<node>_<name>/<sha256>/
```

Each bundle contains:

- the exact raw device bytes
- `metadata.json`
- `manifest.json`
- a WAV export when the PCM format is supported

The slot directory also contains an atomic `latest.json` pointer. Existing
content is never replaced by different bytes under the same hash.

## References

- Teenage Engineering EP Sample Tool:
  https://teenage.engineering/apps/ep-sample-tool
- Offline EP Sample Tool source:
  https://github.com/garrettjwilke/ep_133_sample_tool
- KO II SysEx lab reference:
  https://github.com/generalgroovy/ko2/tree/codex/ko2-sysex-lab
